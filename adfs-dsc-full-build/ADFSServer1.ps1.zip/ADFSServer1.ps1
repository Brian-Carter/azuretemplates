configuration ADFSserver1
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$Thumbprint,
 
        [Parameter(Mandatory)]
        [String]$TimeZone,

        [Parameter(Mandatory)]
        [String]$certificateRemotePath,

        [Parameter(Mandatory)]
        [String]$certificateLocalPath,

        [Parameter(Mandatory)]
        [String]$certificateADFSsubject,
        
        [Parameter(Mandatory)]
        [String]$MachineName,
 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$pfxAdmincreds,
 
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )
 
    Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, PSDesiredStateConfiguration, xTimeZone, xCertificate

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential ]$pfxCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($pfxAdmincreds.UserName)", $pfxAdmincreds.Password)

    if ((Test-Path $CertificateLocalPath) -eq $false) {
    mkdir $CertificateLocalPath
    }
    $fullcertpath = "$CertificateRemotePath\$CertificateADFSsubject.pfx"
    $CertificateLocalPathpfx = "$CertificateLocalPath\$CertificateADFSsubject.pfx"
 
    Node LocalHost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }
	xTimeZone TimeZone 
	{
            IsSingleInstance = 'Yes'
            TimeZone       = $TimeZone
        }
        WindowsFeature ADFSInstall
        {
            Ensure = "Present"
            Name = "ADFS-Federation"
        } 
        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
 
        }
        File ImportFile
        {
            DestinationPath = $CertificateLocalPathpfx
            SourcePath = $fullcertpath
            Ensure = "Present"
            Credential = $domainCreds
            Checksum = "modifiedDate"
            Force = $true
            MatchSource = $True
            DependsOn = "[xWaitForADDomain]DSCForestWait"
        }
        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[WindowsFeature]ADPS"     
        }
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }
        xPfxImport CompanyCert
        {
            Thumbprint = $thumbprint
            Path = $CertificateLocalPathpfx
            Credential = $pfxCredentials
            Location = 'LocalMachine'
            Store = 'My'
            DependsOn = "[File]ImportFile"
        }
    }    
}
$cd = @{
    AllNodes = @(
        @{
            NodeName = 'LocalHost'
	    PSDscAllowDomainUser = $true
            PSDscAllowPlainTextPassword = $true
        }
    )
}