configuration wapserver02
{
    param
    (
        [Parameter(Mandatory)]
        [String]$Thumbprint,
 
        [Parameter(Mandatory)]
        [String]$TimeZone,

        [Parameter(Mandatory)]
        [String]$certificateRemotePath,

        [Parameter(Mandatory)]
        [String]$certificateLocalPath,
        
        [Parameter(Mandatory)]
        [String]$certificateADFSsubject,

        [Parameter(Mandatory)]
        [String]$domainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$pfxAdmincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$domainadmincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
 
    )
 
    Import-DscResource -ModuleName xCertificate, PSDesiredStateConfiguration, xTimeZone, xActiveDirectory

    [System.Management.Automation.PSCredential ]$pfxCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($pfxAdmincreds.UserName)", $pfxAdmincreds.Password)

    [System.Management.Automation.PSCredential ]$domainCredentials = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($domainAdmincreds.UserName)", $domainAdmincreds.Password)

   
    if ((Test-Path $CertificateLocalPath) -eq $false) {
    mkdir $CertificateLocalPath
    }

    $fullcertpath = "$CertificateRemotePath\$CertificateADFSsubject.pfx"
    $CertificateLocalPathpfx = "$CertificateLocalPath\$CertificateADFSsubject.pfx"
 
    Node LocalHost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }
         WindowsFeature WAPInstall
        {
            Ensure = "Present"
            Name = "Web-Application-Proxy"
        } 
        WindowsFeature WAPMgmt
        {
            Ensure = "Present"
            Name = "RSAT-RemoteAccess"
        } 
        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }
        File ImportFile
        {
            DestinationPath = $CertificateLocalPathpfx
            SourcePath = $fullcertpath
            Ensure = "Present"
            Credential = $domainCredentials
            Checksum = "modifiedDate"
            Force = $true
            MatchSource = $True
            DependsOn = "[xWaitForADDomain]DSCForestWait"
        }
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $domainCredentials
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
        } 
	    xPfxImport CompanyCert
        {
            Thumbprint = $thumbprint
            Path = $CertificateLocalPathpfx
            Credential = $pfxCredentials
            Location = 'LocalMachine'
            Store = 'My'
            DependsOn = "[File]ImportFile"
        }
        xTimeZone TimeZone 
	    {
            IsSingleInstance = 'Yes'
            TimeZone = $TimeZone
        }
    }    
}
$cd = @{
    AllNodes = @(
        @{
            NodeName = 'LocalHost'
	    PSDscAllowDomainUser = $true
            PSDscAllowPlainTextPassword = $true
        }
    )
}